package hu.ait.todocompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import dagger.hilt.android.AndroidEntryPoint
import hu.ait.todocompose.navigation.MainNavigation
import hu.ait.todocompose.ui.screen.LoadingScreen
import hu.ait.todocompose.ui.screen.SummaryScreen
import hu.ait.todocompose.ui.screen.TodoListScreen
import hu.ait.todocompose.ui.theme.TodoComposeTheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TodoComposeTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) {
                        innerPadding ->
                    TodoAppNavHost(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun TodoAppNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    startDestination: String = MainNavigation.TodoListScreen.route
) {
    NavHost(navController = navController, startDestination = startDestination
    ) {
        composable(MainNavigation.TodoListScreen.route) {
            TodoListScreen(
                onNavigateToSummary = { all, important ->
                    navController.navigate(
                        MainNavigation.SummaryScreen.createRoute(all, important))
                }
            )
        }

        composable(MainNavigation.SummaryScreen.route,
            // extract all and important arguments
            arguments = listOf(
                navArgument("all"){type = NavType.IntType},
                navArgument("important"){type = NavType.IntType})
        ) {
            val numalltodo = it.arguments?.getInt("all")
            val numimportant = it.arguments?.getInt("important")
            if (numalltodo != null && numimportant != null) {
                SummaryScreen(
                    numalltodo = numalltodo,
                    numimportanttodo = numimportant
                )
            }
        }
    }
}

@Composable
fun SplashScreen(navController: NavHostController = rememberNavController()) {
    LaunchedEffect(Unit){
        kotlinx.coroutines.delay(3000)
        navController.navigate("todolist"){
            popUpTo("splash"){
                inclusive = true
            }

        }
    }
    LoadingScreen()
}

